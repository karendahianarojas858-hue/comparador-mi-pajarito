
Comparador Mi Pajarito - paquete para Render

Instrucciones:

1) Descomprime este ZIP.
2) Verifica que 'tabla_enlaces_imagenes.xlsx' esté presente (tiene columnas Nombre, ImagenDrive, Subpagina).
3) Instala dependencias: pip install -r requirements.txt
4) Ejecuta: python app.py

Deploy en Render:
- Subir como repositorio o ZIP. Comando: python app.py
- Cambia el archivo Excel si necesitas actualizar enlaces.
